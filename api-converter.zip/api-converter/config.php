<?php

    // salvam configuratii in fileul dat
    
    $config = [
        'ACCESS_KEY' => '34d2469e4d27155a6a487cdc6e40ae48',
        'currencies' => [
            'MDL',
            'USD',
            'EUR',
            'RON',
            'RUB'
        ]
    ];

?>