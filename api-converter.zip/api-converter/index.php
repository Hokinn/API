<!-- // MAIN LOGIC -->

<?php
    // conectam biblioteca noastra!
    include 'config.php';
    include 'lib.php';


    welcome();
    // mai intii cautam datele locale
    $data = loadData();  // a lucrat fara a recurge la fixer.io
    if(!$data){
            $data = getFixerData();
            saveData($data);
    }

    // getFixerData(); 
   
    // var_dump($data);
?>

<form>
    <table border="1">
        <?php foreach($config['currencies'] as $value) { ?>
        <tr>
            <td><input type="radio" name="currency" value="<?php print $value; ?>"></td>
            <td><?php print $value; ?></td>
            <td><?printf("%05.2f", $data['rates'][$value] ); ?></td>
        </tr>
        <?php } ?>
        <tr>
            <td colspan="3">
                <input type="text" name="amount" placeholder="insert here">  
                <button>CONVERT</button>
            </td>
        </tr>
    </table>
</form>
<!-- // sa transformam in suma si sa prezentam ce am ales sa convertam! -->