<!-- // UTILITY / SECONDARY FILE /COLLECTION OF FUNCTIONS-->

<?php


    function welcome(){
        print "<h1>welcome</h1>";
    }

    function getFixerData(){ // toate var din functie sunt locale!
        global $config;
        // 1) request - response in format JSON / string
        // se va conecta la provider si ne va citi de acolo cele mai curente coificiente de valuta
        $response = file_get_contents(
            "http://data.fixer.io/api/latest?access_key=".$config["ACCESS_KEY"]   //primim info
        );
        // 2) decodam
        $data = json_decode($response, true);

        // 3) intoarcem datele, (functia doar ia datele, de fiecare data cind o chemam, cu return folosim mai departe)
        return $data; // array
        // var_dump($data); 
    }

    function saveData( $data ){
        $today = date("Y-m-d");
        $ser = serialize($data);
        file_put_contents("database/$today.txt", $ser);
    }
    function loadData(){
        $today = date("Y-m-d");
        if(file_exists("database/$today.txt")){
            $ser = file_get_contents("database/$today.txt"); 
            $data = unserialize($ser);
        } else{
            $data = null;
        }
        return $data;
    }

?>